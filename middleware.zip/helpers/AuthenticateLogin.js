const jwt = require("jsonwebtoken");
let responseObject = require("../controllers/ViewController");
let ErrorMessages = require("../helpers/ErrorMessages");
let User = require("../model/User");
let LoginAuthModel = require("../model/LoginAuthModel");
let PasswordHasher = require("../helpers/PasswordHasher");
User = new User();
LoginAuthModel = new LoginAuthModel();
responseObject = new responseObject();
ErrorMessages = new ErrorMessages();
PasswordHasher = new PasswordHasher();

const verifyToken = async (req) => {
  return new Promise(function (resolve, reject) {
    jwt.verify(req.token, "secretkey", async (err, authData) => {
      if (err) {
        reject(err);
      } else {

        //first  select frm the login auth table
        const selectToken = await LoginAuthModel.selectOneLogin([
          ['token_secret', '=', req.token],['logged_out', '=', 'none']
        ]);

        let hashedToken = await PasswordHasher.hashPassword(req.token);
        resolve(hashedToken);
        /*if (
            !(this.PasswordHasher.comparePassword(password, user.password))
        ) {
          let message = ErrorMessages.ErrorMessageObjects.authentication_failed
          reject(message);
        }*/

        if(selectToken === false){
          let message = ErrorMessages.ErrorMessageObjects.authentication_failed
          reject(message);
        }
        resolve(authData);
      }
    });

  });
};

////router.use("/post", verifyToken);
module.exports = verifyToken;
